# Decisions

<!--
Append-only, newest first. One entry per significant choice — architecture,
library, data model, tradeoff. This replaces retro documents: process lessons
go here too, in one line, or into Claude Code auto memory.
Entry template: date — title [related ID] / Context / Decision / Consequences & rejected.
Example below — replace with real ones.
-->

## 2026-07-05 — Local parquet cache instead of Redis [T-004]
Context: single-user tool, no shared state; Redis adds an always-on dependency.
Decision: cache OHLCV pulls as parquet under `.cache/`, keyed by symbol+date, TTL 24h.
Consequences: zero infra; no cross-machine sharing (accepted). Rejected: Redis (overkill), SQLite (poor columnar reads).
