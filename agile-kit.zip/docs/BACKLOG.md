# Backlog

<!--
Format:  - [ ] ID (P1|P2|P3, S|M|L) one-line title
IDs:     T-### tasks/features, B-### bugs. Never reuse an ID.
Size:    S < 1h focused work · M = one session / one PR · L = must be split before entering Next.
Ready:   an item may enter Now only with acceptance criteria (AC) and size ≤ M.
WIP:     max 1 item in Now.
Cap:     keep this file ≤ 100 lines — /groom prunes Done to CHANGELOG.md.
Example entries below — replace with real ones.
-->

## Now (WIP limit: 1)
- [ ] T-003 (P1, M) Add retry with backoff to price fetcher
  - AC: 3 retries, exponential backoff + jitter; raises `FetchError` after exhaustion; unit tests cover success-after-retry and exhaustion paths
  - Plan: docs/plans/T-003.md

## Next (ordered by priority; ready = has AC, size ≤ M)
- [ ] B-002 (P1, S) Crash on empty input CSV — repro: `python run.py --file tests/data/empty.csv`
- [ ] T-004 (P2, M) Cache daily OHLCV pulls locally
  - AC: second identical pull hits cache; TTL 24h; `--no-cache` bypass flag

## Later (ideas — no AC or sizing required yet)
- [ ] T-005 Portfolio drawdown report
- [ ] T-006 Alert on unusual volume

## Done (recent only — pruned by /groom)
- [x] T-001 (P1, M) Project scaffold + CI — 2026-07-01, `a1b2c3d`
