# <Project Name>

<One line: what this project does and for whom.>

## Stack
<Language + version, framework, DB, key libs — e.g. Python 3.12, pandas, DuckDB, yfinance>

## Commands
- Setup: `<...>`
- Run: `<...>`
- Test: `<...>`
- Lint / format: `<...>`
- Build / deploy: `<...>`

## Layout
```
src/     # <what lives here>
tests/   # mirrors src/
docs/    # standards, ADRs, runbooks
```

## Conventions
- Commits: Conventional Commits (`feat|fix|refactor|test|docs|chore|perf(scope): msg`), atomic and bisectable.
- Errors: typed domain errors (`OrderNotFoundError`), never raw strings; recoverable → retry, non-recoverable → fail fast.
- Validate all input at the boundary (Pydantic / Zod) before any business logic runs.
- Logging: structured JSON to stdout; include `timestamp`, `level`, `durationMs`; never PII or secrets.
- Tests: name `should_X_when_Y`; one concept per test; mock external deps, never own code; builders/factories over magic literals.
- API endpoints (if any): 4xx = client fault, 5xx = ours, never 200 with an error body.
- Naming: booleans prefixed `is/has/can/should`; functions start with a verb; no non-obvious abbreviations.

## Gotchas
<Highest-value section — project-specific traps Claude would otherwise hit.
Examples: "provider X rate-limits at 5 req/s", "source CSVs use US date format",
"prices are split-adjusted only after 2019", "module Y must not import module Z".>

## Task management
- Single source of truth: `docs/BACKLOG.md`. Read it only when running /groom, /next, /plan, /close, /bug, or when I reference a task ID — never load it otherwise.
- IDs: `T-###` tasks, `B-###` bugs. Reference them in commits (`fix(io): handle empty CSV [B-002]`) and TODOs (`TODO(B-002): ...`).
- WIP limit 1. Nothing enters Now without acceptance criteria and size ≤ M (M = fits one session / one PR).
- Decisions worth keeping go to `docs/DECISIONS.md`, not chat history or plan files.

## Reference
Full standards: @docs/engineering-standards.md — read only when designing services, reviewing architecture, or setting up CI. Do not apply the microservices/CI sections to scripts or prototypes.
